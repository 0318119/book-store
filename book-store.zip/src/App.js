
import Routings from './Routing/index'
function App() {
  return (
    <>
      <Routings />
    </>
  );
}

export default App;
